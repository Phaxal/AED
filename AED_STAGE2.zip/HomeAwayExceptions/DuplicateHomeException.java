package HomeAwayExceptions;

public class DuplicateHomeException extends RuntimeException{

	private static final long serialVersionUID = 0L;
	
	public DuplicateHomeException() {
		super();
	}

	public DuplicateHomeException (String message ) {
		super(message);
	}

}