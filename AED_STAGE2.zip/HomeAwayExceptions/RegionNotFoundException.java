package HomeAwayExceptions;

public class RegionNotFoundException extends RuntimeException{

	private static final long serialVersionUID = 0L;
	
	public RegionNotFoundException() {
		super();
	}

	public RegionNotFoundException(String message ) {
		super(message);
	}

}