package HomeAwayExceptions;

public class DuplicateUserException extends RuntimeException{

	private static final long serialVersionUID = 0L;
	
	public DuplicateUserException() {
		super();
	}

	public DuplicateUserException (String message ) {
		super(message);
	}

}