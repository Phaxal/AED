package HomeAwayExceptions;

public class HomeNotFoundException extends RuntimeException{

	private static final long serialVersionUID = 0L;
	
	public HomeNotFoundException() {
		super();
	}

	public HomeNotFoundException (String message ) {
		super(message);
	}

}
