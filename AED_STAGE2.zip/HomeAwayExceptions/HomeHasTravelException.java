package HomeAwayExceptions;

public class HomeHasTravelException extends RuntimeException{

	private static final long serialVersionUID = 0L;
	
	public HomeHasTravelException() {
		super();
	}

	public HomeHasTravelException (String message ) {
		super(message);
	}

}
