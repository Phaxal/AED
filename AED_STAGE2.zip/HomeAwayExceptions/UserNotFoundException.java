package HomeAwayExceptions;

public class UserNotFoundException extends RuntimeException {
	static final long serialVersionUID = 0L;

	public UserNotFoundException() {
		super();
	}

	public UserNotFoundException(String message) {
		super(message);
	}

}
