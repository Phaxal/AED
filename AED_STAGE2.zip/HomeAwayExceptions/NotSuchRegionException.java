package HomeAwayExceptions;

public class NotSuchRegionException extends RuntimeException{

	private static final long serialVersionUID = 0L;
	
	public NotSuchRegionException() {
		super();
	}

	public NotSuchRegionException (String message ) {
		super(message);
	}

}
