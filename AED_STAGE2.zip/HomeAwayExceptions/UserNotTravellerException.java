package HomeAwayExceptions;

public class UserNotTravellerException extends RuntimeException{

	private static final long serialVersionUID = 0L;
	
	public UserNotTravellerException() {
		super();
	}

	public UserNotTravellerException (String message ) {
		super(message);
	}

}