package HomeAwayExceptions;

public class NoCapacityException extends RuntimeException{

	private static final long serialVersionUID = 0L;
	
	public NoCapacityException() {
		super();
	}

	public NoCapacityException(String message ) {
		super(message);
	}

}