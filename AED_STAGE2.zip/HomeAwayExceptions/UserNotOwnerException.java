package HomeAwayExceptions;

public class UserNotOwnerException extends RuntimeException{

	private static final long serialVersionUID = 0L;
	
	public UserNotOwnerException() {
		super();
	}

	public UserNotOwnerException (String message ) {
		super(message);
	}

}
