package HomeAwayExceptions;

public class SearchNotFoundException extends RuntimeException{

	private static final long serialVersionUID = 0L;
	
	public SearchNotFoundException() {
		super();
	}

	public SearchNotFoundException (String message ) {
		super(message);
	}

}
