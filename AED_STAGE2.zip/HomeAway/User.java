/**
 * 
 */
package HomeAway;

import java.io.Serializable;

import dataStructures.Iterator;

/**
 * @author Luis Rosa     - 43612 - lm.rosa@campus.fct.unl.pt
 * @author Diogo Pereira - 44640 - dal.pereira@campus.fct.unl.pt
 */
public interface User extends Serializable {
	
	/**
	 * This interface describes a User object. A User can be a Traveller, Owner or both.
	 * @param String userID 		- Indicates the unique user ID.
	 * @param String name 			- Indicates the name of the User.
	 * @param String email			- Indicates the email of the User.
	 * @param String phone			- Indicates the phone of the User.
	 * @param String address		- Indicates the address of the User.
	 * @param String nationality	- Indicates the nationality of the User.
	 * @param Travel [] travels 	- Array that contains this User's Travels, sorted from most recent to oldest.
	 * @param Home home - This Owner's Home. (Stage 1 & 2 - Every Owner can only have 1 Home.)
	 * */
	
	/**
	 * Verifies if this <code>User</code> has any <code>Travel</code>.
	 * 
	 * @return true if user has travelled, false if not
	 */	
	boolean hasTravel();
	
	
	
	/**
	 * Verifies if this <code>User</code> has any <code>Home</code>.
	 * 
	 * @return true if user owns a home, false if not
	 */	
	boolean hasHome();
	
	
	/**
	 * Verifies if the given <code>Home</code> is owned by this <code>User</code>.
	 * 
	 * @param homeID - the unique home ID
	 * 
	 * @return true if user owns home, false if not
	 */	
	boolean hasHome(String homeID);
	
	/**
	 * Returns this <code>User</code>'s <code>userID</code>.
	 * @return <code>userID</code>
	 */
	String getID();
	
	/**
	 * Returns this <code>User</code>'s <code>email</code>.
	 * @return <code>email</code>
	 */
	String getEmail();
	
	/**
	 * Returns this <code>User</code>'s <code>phone</code>.
	 * @return <code>phone</code>
	 */
	String getPhone ();
	
	/**
	 * Returns this <code>User</code>'s <code>name</code>.
	 * @return <code>name</code>
	 */
	String getName();
	
	/**
	 * Returns this <code>User</code>'s <code>nationality</code>.
	 * @return <code>nationality</code>
	 */
	String getNationality();
	
	/**
	 * Returns this <code>User</code>'s <code>address</code>.
	 * @return <code>address</code>
	 */
	String getAddress();
	
	/**
	 * Returns this <code>Owner</code>'s Home.
	 * @pre: hasHome
	 * @return <code>Owner</code>'s <code>Home</code>
	 */
	Home getHome();
	

	/**
	 * Returns this <code>Owner</code>'s Home.
	 * @param String userID - Indicates the unique User ID.
	 * @pre: hasHome
	 * @return <code>Owner</code>'s <code>Home</code>
	 */	
	Home getHome(String homeID);
	
	/**
	 * Updates this <code>User</code>'s email, phone and address to the given fields.
	 * 
	 * @param String email			- Indicates the email of the User.
	 * @param String phone			- Indicates the phone of the User.
	 * @param String address		- Indicates the address of the User.
	 */
	void updateUser(String email, String phone, String address);
	
	/**
	 * Adds a <code>Travel</code> to the given <code>Home</code>.
	 * 
	 * @param int score - the score given to this Travel. 0 if User is also Owner.
	 * @param Home home - the Home to which the Travel was made.
	 */
	void addTravel(int score, Home home);	
	
	
	/**
	 * Adds a <code>Home</code> to this <code>User</code>.
	 * 
	 * @param home - the home to be added.
	 * 
	 * @pre !hasHome
	 */
	void addHome(Home home);
	
	
	
	/**
	 * Removes a <code>Home</code> from this <code>User</code>.
	 * 
	 * @param home - the home to be removed.
	 * 
	 * @pre hasHome
	 * @pre !hasTravel
	 */
	void removeHome(Home home);
	
	
	
	/**
	 * Lists (returns an <code>Iterator</code> to) all <code>Travel</code>s this <code>User</code> has made, 
	 * sorted from most recent to oldest.
	 * @return <code>Iterator</code>
	 */
	Iterator <Travel> listTravels();

	
	
	/**
	 * Lists (returns an <code>Iterator</code> to) all <code>Home</code>s this <code>User</code> owns. 
	 * 
	 * @pre hasHome
	 * 
	 * @return <code>Iterator</code> - Stage 1 and 2 - Returns a single home.
	 */
	Home listHomes();



	String getKey();

}
