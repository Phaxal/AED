package HomeAway;

public class HomeClass implements Home {

	private static final long serialVersionUID = 0L;

	private String homeID;
	private String homeKey;
	private User owner;
	private Region region;
	private int price;
	private int capacity;
	private String description;
	private String address;
	private int totalScore;
	private boolean travel;

	public HomeClass(String homeID, User owner, int price, int capacity,
			Region region, String description, String address) {
		totalScore = 0;
		travel = false;
		this.homeID = homeID;
		this.homeKey = homeID.toLowerCase();
		this.owner = owner;
		this.price = price;
		this.capacity = capacity;
		this.description = description;
		this.address = address;
		this.region = region;
		region.addHome(this);
	}

	@Override
	public boolean isSameRegion(Region region) {
		return this.region.equals(region);
	}

	@Override
	public boolean hasTravel() {
		return travel;
	}

	@Override
	public void addTravel(int score) {
		travel = true;
		updateScore(score);
	}

	@Override
	public String getDescription() {
		return description;
	}

	@Override
	public String getAddress() {
		return address;
	}

	@Override
	public String getID() {
		return homeID;
	}

	@Override
	public User getUser() {
		return owner;
	}

	@Override
	public String getKey() {
		return homeKey;
	}

	@Override
	public int getPrice() {
		return price;
	}

	@Override
	public int getCapacity() {
		return capacity;
	}

	@Override
	public int getTotalScore() {
		return totalScore;
	}

	private void updateScore(int score) {
		totalScore += score;
	}

	@Override
	public Region getRegion() {
		return region;
	}
}
