package HomeAway;

public class RegionClass implements Region {
	
	private static final long serialVersionUID = 0L;
	
	private String key;
	private String name;
	private Home home;

	public RegionClass(String name){
		this.key = name.toLowerCase();
		this.name = name;
		home = null;
	}
	
	@Override
	public String getRegionName(){
		return name;
	}
	
	@Override
	public String getKey(){
		return key;
	}
	
	@Override
	public boolean hasHome() {
		return home != null;
	}

	@Override
	public Home listHome() {
		return home;
	}

	@Override
	public void addHome(Home home) {
		this.home = home;
	}

	@Override
	public void removeHome(Home home) {
		this.home = null;
	}
	

}
