package HomeAway;

import java.io.Serializable;

/**
 * @author Luis Rosa     - 43612 - lm.rosa@campus.fct.unl.pt
 * @author Diogo Pereira - 44640 - dal.pereira@campus.fct.unl.pt
 */

public interface Travel extends Serializable{
	
	/**
	 * This interface describes a Travel object.
	 * @param Home home	- Home to which the Travel was made.
	 * @param int score - Score given to this Travel. If the User who made this Travel
	 * is also the owner of this Home, score will always be 0.
	 */

	/**
	 * Returns the <code>Home</code> to which this <code>Travel</code> was made.
	 * @return <code>Home</code> of this <code>Travel</code>
	 */
	Home getHome();
	
	/**
	 * Returns the <code>score</code> given to this <code>Travel</code>.
	 * @return <code>Score</code> of this <code>Travel</code>
	 */
	int getScore();
	
}
