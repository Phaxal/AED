package HomeAway;

import HomeAwayExceptions.*;
import dataStructures.ChainedHashTable;
import dataStructures.Dictionary;
import dataStructures.Iterator;

public class HomeAwayClass implements HomeAway {

	private static final long serialVersionUID = 0L;

	private Dictionary<String, User> users;
	private Dictionary<String, Home> homes;
	private Dictionary<String, Region> regions;

	public HomeAwayClass(int capacity) {
		regions = new ChainedHashTable<String, Region>(capacity);
		homes = new ChainedHashTable<String, Home>(capacity);
		users = new ChainedHashTable<String, User>(capacity);
	}

	@Override
	public boolean hasUser() {
		return !users.isEmpty();
	}

	@Override
	public boolean hasUser(String userID) {
		return users.find(userID) != null;
	}

	@Override
	public boolean hasHome() {
		return !homes.isEmpty();
	}

	@Override
	public boolean hasHome(String homeID) throws HomeNotFoundException {
		return homes.find(homeID) != null;
	}

	@Override
	public boolean userHasHome(String userID, String homeID) {
		// simple implementation, 1 user and 1 home
		return hasUser(userID) && hasHome(homeID);
	}

	@Override
	public boolean hasTravel(String homeID) {
		return getHome(homeID).hasTravel();
	}

	@Override
	public boolean hasRegion(String region) {
		return regions.find(region) != null;
	}

	@Override
	public boolean regionHasCapacity(String region, int capacity)
			throws RegionNotFoundException {
		boolean reg = hasRegion(region);
		if (reg)
			return regions.find(region).listHome().getCapacity() >= capacity;
		else
			throw new RegionNotFoundException();
	}

	@Override
	public boolean isTraveller(String userID) throws UserNotFoundException,
			UserNotTravellerException {
		boolean traveller = users.find(userID).hasTravel();
		if (traveller)
			return true;
		else
			throw new UserNotTravellerException();
	}

	@Override
	public boolean isOwner(String userID) throws UserNotFoundException,
			UserNotOwnerException {
		boolean owner = users.find(userID).hasHome();
		owner = true;
		if (owner)
			return true;
		else

			throw new UserNotOwnerException();
	}

	@Override
	public User getUser(String userID) throws UserNotFoundException {

		User user = users.find(userID);
		if (user == null)
			throw new UserNotFoundException();
		return user;
	}

	@Override
	public void insertUser(String userID, String email, String phone,
			String name, String nationality, String address)
			throws DuplicateUserException {
		if (users.find(userID) != null)
			throw new DuplicateUserException();
		else {
			User user = new UserClass(userID, email, phone, address, name,
					nationality);
			users.insert(userID, user);
		}
	}

	@Override
	public void updateUser(String userID, String email, String phone,
			String address) {
		if (hasUser(userID))
			users.find(userID).updateUser(email, phone, address);

		else
			throw new UserNotFoundException();
	}

	@Override
	public void removeUser(String userID) throws UserNotFoundException,
			UserIsOwnerException {

		if (hasUser(userID))
			if (!users.find(userID).hasHome())
				users.remove(userID);
			else
				throw new UserIsOwnerException();
		else
			throw new UserNotFoundException();
	}

	@Override
	public void addHome(String homeID, String userID, int price, int capacity,
			String region, String description, String address)
			throws DuplicateHomeException, UserNotFoundException {

		if (!hasUser(userID.toLowerCase()))
			throw new UserNotFoundException();
		if (hasHome(homeID.toLowerCase()))
			throw new DuplicateHomeException();
		if (!this.hasRegion(region.toLowerCase()))
			regions.insert(region.toLowerCase(), new RegionClass(region));

		Home home = new HomeClass(homeID, getUser(userID), price, capacity,
				getRegion(region.toLowerCase()), description, address);
		homes.insert(homeID.toLowerCase(), home);
		getUser(userID.toLowerCase()).addHome(home);
	}

	@Override
	public void removeHome(String homeID) throws HomeNotFoundException {
		if (hasHome(homeID.toLowerCase())) {
			Home home = homes.find(homeID.toLowerCase());
			regions.find(home.getRegion().getKey()).addHome(null);
			home.getUser().addHome(null);
			homes.remove(homeID.toLowerCase());
		} else
			throw new HomeNotFoundException();
	}

	@Override
	public Home getHome(String homeID) throws HomeNotFoundException {

		Home h = homes.find(homeID.toLowerCase());
		if (h == null)
			throw new HomeNotFoundException();
		return h;
	}

	@Override
	public void addTravel(String userID, String homeID, int score)
			throws UserNotFoundException, HomeNotFoundException {
		getUser(userID.toLowerCase()).addTravel(score,
				getHome(homeID.toLowerCase()));
	}

	@Override
	public Home listHome(String userID) throws UserNotFoundException,
			UserNotOwnerException {
		if (hasUser(userID.toLowerCase())) {
			if (getUser(userID.toLowerCase()).hasHome()) {
				return getUser(userID.toLowerCase()).getHome();
			} else
				throw new UserNotOwnerException();
		} else
			throw new UserNotFoundException();
	}

	@Override
	public Iterator<Travel> listTravels(String userID)
			throws UserNotFoundException, UserNotTravellerException {
		if (!this.hasUser(userID))
			throw new UserNotFoundException();
		if (!getUser(userID.toLowerCase()).hasTravel())
			throw new UserNotTravellerException();
		return getUser(userID.toLowerCase()).listTravels();
	}

	@Override
	public Home pollHome(int capacity, String region)
			throws RegionNotFoundException, NoCapacityException,
			HomeNotFoundException {

		Home home;
		if (hasRegion(region.toLowerCase())) {
			Region reg = regions.find(region.toLowerCase());
			if (reg.hasHome()) {
				home = regions.find(region.toLowerCase()).listHome();
			} else
				throw new HomeNotFoundException();
		} else {
			throw new RegionNotFoundException();
		}
		if (!(home.getCapacity() < capacity))
			return home;
		else {
			throw new NoCapacityException();
		}
	}

	@Override
	public Home listBest(String region) throws RegionNotFoundException,
			HomeNotFoundException {

		if (!hasRegion(region))
			throw new RegionNotFoundException();
		Region reg = regions.find(region);
		if (reg.hasHome())
			return regions.find(region).listHome();
		else
			throw new HomeNotFoundException();
	}

	@Override
	public Region getRegion(String region) throws RegionNotFoundException {

		Region reg = regions.find(region);
		if (reg == null)
			throw new RegionNotFoundException();
		return reg;
	}
}
