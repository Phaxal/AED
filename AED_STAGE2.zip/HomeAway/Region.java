package HomeAway;

import java.io.Serializable;

/**
 * @author Luis Rosa     - 43612 - lm.rosa@campus.fct.unl.pt
 * @author Diogo Pereira - 44640 - dal.pereira@campus.fct.unl.pt
 */

public interface Region extends Serializable{
	
	/**
	 * This interface describes a Region object.
	 * @param String name 	- Indicates the unique region name.
	 * @param Home home		- The Home available for renting in this Region.
	 * */
	
	/**
	 * Comments for stage 3
	 * Lists (returns an <code>Iterator</code> to) all <code>Home</code>s available for renting in this <code>Region</code>, 
	 * sorted by accumulated score, from highest rated to lowest rated.
	 * @return <code>Iterator</code> to highest rated <code>Home</code>s
	 * 
	 * Iterator <Home> listBest();
	 * 
	 * * Lists (returns an <code>Iterator</code> to) all <code>Home</code>s available for renting in this <code>Region</code>
	 * that can accommodate <code>capacity</code> number of people.
	 * @param: int <code>capacity</code> - number of people to accommodate.
	 * @return <code>Iterator</code> to <code>Home</code>s with <code>capacity</code>
	 * 
	 * Iterator <Home> pollHome(int capacity);
	 */
	
	/**
	 * This method assesses if this <code>Region</code> has any <code>Home</code> available for rent.
	 * 
	 * @return true if <code>Region</code> has a <code>Home</code>, false if not.
	 */
	boolean hasHome();
	
	/**
	 * This method returns the <code>Home</code> present in this <code>Region</code>.
	 * 
	 * @pre hasHome
	 * 
	 * @return the <code>Home</code> of this <code>Region</code>.
	 */
	Home listHome();
	
	/**
	 * Adds a <code>Home</code> to this <code>Region</code>.
	 * @param: <code>Home</code> home - home to insert.
	 * @pre: !hasHome
	 */
	void addHome(Home home);
	
	/**
	 * Removes a <code>Home</code> from this <code>Region</code>.
	 * @param: <code>Home</code> home - home to remove.
	 * @pre: !hasTravel
	 */
	void removeHome(Home home);
	
	/**
	 * Returns the unique <code>Region</code> identifier (name)
	 * 
	 * @return <code>Region</code> name
	 */
	String getRegionName();

	String getKey();

}
