/**
 * 
 */
package dataStructures;
import java.io.Serializable;
/**
 * @author Luis Rosa     - 43612 - lm.rosa@campus.fct.unl.pt
 * @author Diogo Pereira - 44640 - dal.pereira@campus.fct.unl.pt
 */
public interface IterableStack<E> extends Stack<E>, Serializable {
	
	static final long serialVersionUID = 0L;
	
	 /**
     *  Returns an iterator of the elements in the stack (in proper sequence).
     * @return Iterator of the elements in the stack
     */
    Iterator<E> iterator( );
	

}
