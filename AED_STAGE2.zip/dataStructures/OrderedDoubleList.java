package dataStructures;

public class OrderedDoubleList<K extends Comparable<K>, V> implements
		OrderedDictionary<K, V> {

	private static final long serialVersionUID = 1L;

	protected DListNode<Entry<K, V>> head;

	protected DListNode<Entry<K, V>> tail;

	protected int currentSize;

	public OrderedDoubleList() {
		head = null;
		tail = null;
		currentSize = 0;
	}

	public V find(K key) {
		Iterator<Entry<K, V>> it = iterator();
		while (it.hasNext()) {
			Entry<K, V> temp = it.next();
			if (temp.getKey().compareTo(key) == 0)
				return temp.getValue();
			if (temp.getKey().compareTo(key) > 0)
				return null;
		}
		return null;
	}

	public DListNode<Entry<K, V>> findNode(K key) {
		DListNode<Entry<K, V>> node = head;
		while (node != null) {
			if (node.getElement().getKey().compareTo(key) >= 0)
				return node;
			node = node.getNext();
		}
		return null;

	}

	public V insert(K key, V value) {
		if (currentSize == 0) {
			DListNode<Entry<K, V>> novo = new DListNode<Entry<K, V>>(
					new EntryClass<K, V>(key, value), null, null);
			head = novo;
			tail = novo;
			currentSize++;
		}
		else {
			DListNode<Entry<K, V>> node = findNode(key);
			if (node == null) {
				DListNode<Entry<K, V>> newNode = new DListNode<Entry<K, V>>(
						new EntryClass<K, V>(key, value), tail, null);
				tail.setNext(newNode);
				tail = newNode;
				currentSize++;

			} 
			else if (key.compareTo(node.getElement().getKey()) < 0) {
				DListNode<Entry<K, V>> newNode = new DListNode<Entry<K, V>>(
						new EntryClass<K, V>(key, value), node.getPrevious(),
						node);
				DListNode<Entry<K, V>> temp;
				if ((temp = node.getPrevious()) == null) {
					head = newNode;
				} 
				else{
					temp.setNext(newNode);
				}
				node.setPrevious(newNode);
				currentSize++;
			}
			else if (key.compareTo(node.getElement().getKey()) == 0) {
				Entry<K, V> newEntry = new EntryClass<K, V>(key, value);
				V ret = node.getElement().getValue();
				node.setElement(newEntry);
				return ret;
			}
		}
		return null;
	}

	public boolean isEmpty() {
		return (currentSize == 0);
	}

	public Iterator<Entry<K, V>> iterator() {

		return new DoublyLLIterator<Entry<K, V>>(head, tail);
	}

	public Entry<K, V> maxEntry() throws EmptyDictionaryException {

		return tail.getElement();
	}

	public Entry<K, V> minEntry() throws EmptyDictionaryException {
		return head.getElement();
	}

	public V remove(K key) {
		DListNode<Entry<K,V>> node = this.findNode(key);
		if (node == null)
			return null;
		else {
			V value = node.getElement().getValue();
			if (node == head){
				if(node.getNext()!=null){
					head = head.getNext();
					head.setPrevious(null);
				}
				else{
					head = null;
					tail = null;
				}
			}
			else if (node.getNext()==tail){
				head = tail;
				tail.setPrevious(null);
			}
			else{
				node.getPrevious().setNext(node.getNext());
				node.getNext().setPrevious(node.getPrevious());
			}
			currentSize--;
			node = null;
			return value;
		}
	}

	public int size() {
		return currentSize;
	}

}
