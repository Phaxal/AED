package dataStructures;
/**
 * @author Luis Rosa     - 43612 - lm.rosa@campus.fct.unl.pt
 * @author Diogo Pereira - 44640 - dal.pereira@campus.fct.unl.pt
 */
public class OwnerScoreException extends Exception {

    static final long serialVersionUID = 0L;

    public OwnerScoreException(){
        super();
    }

    public OwnerScoreException(String message) {
        super(message);
    }

}
