package HomeAway;

import dataStructures.Iterator;

public class RegionClass implements Region {
	
	private static final long serialVersionUID = 0L;
	
	//Let's leave this alone for now (Stage 2)

	@Override
	public Iterator<Home> listBest() {
		return null;
	}

	@Override
	public Iterator<Home> pollHome(int capacity) {
		return null;
	}

	@Override
	public void addHome(Home home) {

	}

	@Override
	public void removeHome(Home home) {

	}

}
