/**
 * 
 */
package HomeAway;

import java.io.Serializable;

/**
 * @author Luis Rosa     - 43612 - lm.rosa@campus.fct.unl.pt
 * @author Diogo Pereira - 44640 - dal.pereira@campus.fct.unl.pt
 */
public interface Home extends Serializable{

	/**
	 * This interface describes a Home object.
	 * @param boolean travel 		- Indicates if this Home has any Travel.
	 * @param String homeID 		- Indicates the unique home ID.
	 * @param Owner owner 			- Indicates the Owner associated with this Home object.
	 * @param int price 			- Indicates the price per person for a Travel to this Home object.
	 * @param int capacity			- Indicates the maximum number of people able to be housed.
	 * @param int totalScore		- Indicates the accumulated score of this Home.
	 * @param String address		- Indicates the address where the Home is located.
	 * @param String description 	- A brief description of this Home.
	 * @param String region			- Indicates the region in which this Home is located.
	 * */

	/**
	 * Verifies if this <code>Home</code> is in the given <code>Region</code>.
	 * 
	 * @return true if home is in region, false if not
	 */	
	boolean isSameRegion(String region);
	
	/**
	 * Verifies if this<code>Home</code> has had any <code>Travel</code> to it.
	 * 
	 * @return true if home has had at least one travel, false if not
	 */
	boolean hasTravel();
	
	/**
	 * Adds a <code>Travel</code> to this <code>Home</code>.
	 */
	void addTravel();
	
	/**
	 * Returns this <code>Home</code> object's <code>homeID</code>.
	 * @return object's <code>homeID</code>.
	 */
	String getID();
	
	/**
	 * Returns this <code>Home</code> object's <code>description</code>.
	 * @return a <code>description</code> of this <code>Home</code>.
	 */
	String getDescription();
	
	/**
	 * Returns this <code>Home</code> object's <code>address</code>.
	 * @return the <code>address</code> of this <code>Home</code>.
	 */
	String getAddress();
	
	/**
	 * Returns the <code>User</code> who owns this <code>Home</code>.
	 * @return <code>User</code> of this <code>Home</code>.
	 */
	User getUser();
	
	/**
	 * Returns the price of this <code>Home</code> object.
	 * @return price of this <code>Home</code> object.
	 */
	int getPrice();
	
	/**
	 * Returns the <code>number</code> of people this <code>Home</code> can house.
	 * @return <code>number</code> of people this <code>Home</code> can house.
	 */
	int getCapacity();
	
	
	/**
	 * Returns the accumulated <code>score</code> this <code>Home</code> has received.
	 * @return <code>totalScore</code> of this <code>Home</code>.
	 */
	int getTotalScore();	
	

	
	/**
	 * Updates the accumulated <code>score</code> this <code>Home</code> has received by adding the given value.
	 * 
	 * @param - int score - The score to add to this Home.
	 * Score will be 0 if the User who performs this Travel is also the Home's Owner.
	 * 
	 * @pre score > 0
	 */
	void updateScore(int score);
	
	
	
	/**
	 * Returns the <code>region</code> where this <code>Home</code> is located.
	 * @return <code>region</code> where this <code>Home</code> is located.
	 */
	String getRegion();

}
