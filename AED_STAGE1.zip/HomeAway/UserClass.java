/**
 * 
 */
package HomeAway;

import dataStructures.DoublyLinkedList;
import dataStructures.Iterator;

/**
 * @author Luis Rosa     - 43612 - lm.rosa@campus.fct.unl.pt
 * @author Diogo Pereira - 44640 - dal.pereira@campus.fct.unl.pt
 */
public class UserClass implements User {
	
	private static final long serialVersionUID = 0L;
	
	private String userID;
	private String email;
	private String phone;
	private String name;
	private String address;
	private String nationality;
	private Home home;
	private DoublyLinkedList<Travel> travels;
	
	public UserClass(String userID, String email, String phone, String address, String name, String nationality){
		home = null;
		this.userID = userID;
		this.name = name;
		this.nationality = nationality;
		updateUser(email, phone, address);
		travels = new DoublyLinkedList<Travel>();
	}
	
	@Override
	public boolean hasTravel() {
		return !travels.isEmpty();
	}

	@Override
	public boolean hasHome() {
		return home != null;
	}
	
	@Override
	public boolean hasHome(String homeID) {
		return home.getID().equals(homeID);
	}

	@Override
	public String getID() {
		return userID;
	}
	@Override
	public String getEmail() {
		return email;
	}
	@Override
	public String getPhone() {
		return phone;
	}

	@Override
	public String getName() {
		return name;
	}
	@Override
	public String getNationality() {
		return nationality;
	}
	@Override
	public String getAddress() {
		return address;
	}
	
	@Override
	public Home getHome() {
		return home;
	}
	
	@Override
	public Home getHome(String homeID) {
		return home;
	}
	
	protected void setEmail(String email) {
		this.email = email;
	}

	protected void setPhone(String phone) {
		this.phone = phone;
	}

	protected void setAddress(String address) {
		this.address = address;
	}

	@Override
	public void updateUser(String email, String phone, String address) {
		setEmail(email);
		setPhone(phone);
		setAddress(address);
	}
	
	@Override
	public void addHome(Home home) {
		this.home = home;
	}
	
	@Override
	public void removeHome(Home home) {
		this.home = null;
	}
	
	@Override
	public void addTravel(int score, Home home) {
		travels.addFirst(new TravelClass(score, home));
		home.addTravel();
		home.updateScore(score);
	}

	@Override
	public Iterator<Travel> listTravels() {
		return travels.iterator();
	}

	@Override
	public Home listHomes() {
		return this.getHome();
	}

}
