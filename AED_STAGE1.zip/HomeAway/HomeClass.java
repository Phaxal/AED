package HomeAway;

public class HomeClass implements Home {
	
	//TODO IMPORTANT QUESTION PHASE 2 : do we remove travels from removed users? - Answer - probably no
	
	private static final long serialVersionUID = 0L;
	
	private String homeID;
	private User owner;
	private int price;
	private int capacity;
	private String region;
	private String description;
	private String address;
	private int totalScore;
	private boolean travel;
	
	public HomeClass(String homeID, User owner, int price, int capacity, String region, String description, String address){
		totalScore = 0;
		travel = false;
		this.homeID = homeID;
		this.owner = owner;
		this.price = price;
		this.capacity = capacity;
		this.region = region;
		this.description = description;
		this.address = address;
	}
		
	@Override
	public boolean isSameRegion(String region) {
		return this.region.equals(region);
	}
	
	@Override
	public boolean hasTravel() {
		return travel;
	}
	
	@Override
	public void addTravel() {
		travel = true;
	}
	
	@Override
	public String getDescription() {
		return description;
	}

	@Override
	public String getAddress() {
		return address;
	}
	
	@Override
	public String getID() {
		return homeID;
	}

	@Override
	public User getUser() {
		return owner;
	}

	@Override
	public int getPrice() {
		return price;
	}

	@Override
	public int getCapacity() {
		return capacity;
	}
	
	@Override
	public int getTotalScore() {
		return totalScore;
	}
	
	@Override
	public void updateScore(int score){
		totalScore += score;
	}

	@Override
	public String getRegion() {
		return region;
	}
}
