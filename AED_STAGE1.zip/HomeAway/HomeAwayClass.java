package HomeAway;

import dataStructures.Iterator;
import dataStructures.OwnerScoreException;

public class HomeAwayClass implements HomeAway {
	
	private static final long serialVersionUID = 0L;
	
	private User user;
	private Home home;

/*METHODS OF VERIFY*/
	
	public HomeAwayClass(){
		user = null;
	}
	
	@Override
	public boolean hasUser() {
		return user != null;
	}
	
	@Override
	public boolean hasUser(String userID) {
		return user.getID().equalsIgnoreCase(userID);
	}
	
	@Override
	public boolean hasHome() {
		// TODO Auto-generated method stub
		return home != null;
	}

	@Override
	public boolean hasHome(String homeID) {
		return home.getID().equalsIgnoreCase(homeID);
	}
	
	@Override
	public boolean userHasHome(String userID, String homeID) {
		//simple implementation, 1 user and 1 home
		return hasUser(userID) && hasHome(homeID);
	}

	@Override
	public boolean hasTravel(String homeID) {
		//homeID identifies home, but there is only one home in the system so far
		return user.getHome(homeID).hasTravel();
	}

	@Override
	public boolean hasRegion(String region) {
		//simple implementation, 1 home = 1 region
		return home.getRegion().equalsIgnoreCase(region);
	}

	@Override
	public boolean regionHasCapacity(String region, int capacity) {
		// pre - region exists (it is the region of the home obj)
		return home.getCapacity() >= capacity;
	}

	@Override
	public boolean isTraveller(String userID) {
		// 1 user
		return getUser(userID).hasTravel();
	}

	@Override
	public boolean isOwner(String userID) {
		// 1 user
		return getUser(userID).hasHome();
	}
	
/*METHODS IMPLEMENTED*/
	
	@Override
	public void insertUser(String userID, String email, String phone, String name, String nationality, String address) {
		user = new UserClass(userID, email, phone, address, name, nationality);
	}

	@Override
	public void updateUser(String userID, String email, String phone, String address) {
		getUser(userID).updateUser(email, phone, address);
	}

	@Override
	public void removeUser(String userID) {
		// 1 user
		user = null;
	}

	@Override
	public User getUser(String userID) {
		// 1 user
		return user;
	}

	@Override
	public void addHome(String homeID, String userID, int price, int capacity, String region, String description, String address) {
		// 1 home
		home = new HomeClass(homeID, getUser(userID), price, capacity, region, description, address);
		getUser(userID).addHome(home);
	}

	@Override
	public void removeHome(String homeID) {
		// 1 home
		user.removeHome(getHome(homeID));
		home = null;
	}

	@Override
	public Home getHome(String homeID) {
		// 1 home
		return home;
	}

	@Override
	public void addTravel(String userID, String homeID, int score) throws OwnerScoreException{
		getUser(userID).addTravel(score, getHome(homeID));
	}
	
	/*
	@Override
	public Iterator<Home> listHome(String userID) {
		return getUser(userID).listHomes();
	}

	

	@Override
	public Iterator<Home> pollHome(int capacity, String region) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Iterator<Home> listBest(String region) {
		// TODO Auto-generated method stub
		return null;
	}*/

	@Override
	public Home listHome(String userID) {
		// TODO Auto-generated method stub 
		return getUser(userID).getHome();
	}

	@Override
	public Iterator<Travel> listTraveller(String userID) {
		// TODO Auto-generated method stub
		return getUser(userID).listTravels();
	}

	@Override
	public Home pollHome(int capacity, String region) {
		// TODO Auto-generated method stub
		return home;
	}

	@Override
	public Home listBest(String region) {
		// TODO Auto-generated method stub
		return home;
	}

}
