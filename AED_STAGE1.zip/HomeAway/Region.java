package HomeAway;

import java.io.Serializable;
import dataStructures.Iterator;

/**
 * @author Luis Rosa     - 43612 - lm.rosa@campus.fct.unl.pt
 * @author Diogo Pereira - 44640 - dal.pereira@campus.fct.unl.pt
 */

public interface Region extends Serializable{
	
	/**
	 * This interface describes a Region object.
	 * This interface will only be used from Stage 2 onwards.
	 * @param String name 				- Indicates the unique region name.
	 * @param Home [] homesByScore		- Array that contains the Homes available for renting in this Region, 
	 * sorted by score (best to worst).
	 * @param Home [] homesByID		- Array that contains the Homes available for renting in this Region,
	 * sorted by ID.
	 * */
	
	/**
	 * Lists (returns an <code>Iterator</code> to) all <code>Home</code>s available for renting in this <code>Region</code>, 
	 * sorted by accumulated score, from highest rated to lowest rated.
	 * @return <code>Iterator</code> to highest rated <code>Home</code>s
	 */
	Iterator <Home> listBest();
	
	/**
	 * Lists (returns an <code>Iterator</code> to) all <code>Home</code>s available for renting in this <code>Region</code>
	 * that can accommodate <code>capacity</code> number of people.
	 * @param: int <code>capacity</code> - number of people to accommodate.
	 * @return <code>Iterator</code> to <code>Home</code>s with <code>capacity</code>
	 */
	Iterator <Home> pollHome(int capacity);
	
	/**
	 * Adds a <code>Home</code> to this <code>Region</code>.
	 * @param: <code>Home</code> home - home to insert.
	 * @pre: !hasHome
	 */
	void addHome(Home home);
	
	/**
	 * Removes a <code>Home</code> from this <code>Region</code>.
	 * @param: <code>Home</code> home - home to remove.
	 * @pre: !hasTravel
	 */
	void removeHome(Home home);

}
