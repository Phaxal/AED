/**
 * 
 */
package HomeAway;

import java.io.Serializable;

import dataStructures.Iterator;
import dataStructures.OwnerScoreException;

/**
 * @author Luis Rosa     - 43612 - lm.rosa@campus.fct.unl.pt
 * @author Diogo Pereira - 44640 - dal.pereira@campus.fct.unl.pt
 */
public interface HomeAway extends Serializable{
	
	/**
	 * This interface describes a HomeAway object. It is the top-level interface of this project.
	 * 
	 * @param User user	- Sole user of the HomeAway project (stage 1).
	 * @param Home home	- Sole home of the HomeAway project (stage 1).
	 * */

	/**
	 * Verifies if the system has any <code>User</code>
	 * 
	 * @return true if has user, false if not
	 */
	boolean hasUser();
	
	
	
	/**
	 * Verifies if the given <code>User</code> exists in the system
	 * 
	 * @param String userID - the unique user ID
	 * 
	 * @return true if user exists, false if not
	 */
	boolean hasUser(String userID);
	
	
	/**
	 * Verifies if the system has any <code>Home</code>
	 * 
	 * @return true if has home, false if not
	 */
	boolean hasHome();
	
	
	
	/**
	 * Verifies if the given <code>Home</code> exists in the system
	 * 
	 * @param homeID - the unique home ID
	 * 
	 * @return true if home exists, false if not
	 */
	boolean hasHome(String homeID);
	
	
	
	/**
	 * Verifies if the given <code>Home</code> exists in the properties of given <code>User</code>
	 * 
	 * @param userID 	- the unique user ID of this home's owner
	 * @param homeID 	- the unique home ID
	 * 
	 * @pre hasUser 	- user exists in the system
	 * 
	 * @return true if home exists and is owned by user, false if not
	 */
	boolean userHasHome(String userID, String homeID);
	
	
	
	/**
	 * Verifies if the given <code>Home</code> has had any <code>Travel</code> to it.
	 * 
	 * @param homeID 	- the unique home ID
	 * 
	 * @pre hasHome 	- home exists in the system
	 * 
	 * @return true if home has had at least one travel, false if not
	 */
	boolean hasTravel(String homeID);
	
	
	
	/**
	 * Verifies if the given <code>Region</code> exists in the system.
	 * 
	 * @param region 	- the unique region name
	 * 
	 * @return true if region exists, false if not
	 */
	boolean hasRegion(String region);
	
	
	
	/**
	 * Verifies if the given <code>Region</code> can house <code>capacity</code> people.
	 * 
	 * @param region 			- the unique region name
	 * 
	 * @pre hasRegion(String) 	- region exists in the system
	 * 
	 * @return true if at least one home in region can house capacity people, false if not
	 */
	boolean regionHasCapacity(String region, int capacity);
	
	
	
	/**
	 * Verifies if the given <code>User</code> is a traveller.
	 * 
	 * @param <code>userID</code> 	- the unique user ID
	 * 
	 * @pre <code>hasUser</code> 	- user must exist in the system
	 * 
	 * @return true if Traveller, false if not
	 */
	boolean isTraveller(String userID);
	
	
	
	/**
	 * Verifies if the given <code>User</code> is an owner.
	 * 
	 * @param <code>userID</code>		 	- the unique user ID
	 * 
	 * @pre <code>hasUser</code>			- user must exist in the system
	 * 
	 * @return 								- true if Owner, false if not
	 */
	boolean isOwner(String userID);

	
	
	/**
	 * Inserts a <code>User</code> in the system.
	 * 
	 * @param userID					- Indicates the unique user ID
	 * @param email						- Indicates the email of the user
	 * @param phone						- Indicates the phone of the user
	 * @param name						- Indicates the name of the user 
	 * @param nationality				- Indicates the nationality of the user
	 * @param address					- Indicates the address of the user
	 * 
	 * @pre <code>!hasUser</code>		- precondition if the user ID is already in use
	 * */
	void insertUser(String userID, String email, String phone, String name, String nationality, String address);

	
	
	/** Updates a <code>User</code>'s information in the system, name and nationality cannot be changed

	 * 
	 * @param userID				- Indicates the the unique user ID 
	 * @param email					- Indicates the email of the user
	 * @param phone					- Indicates the phone of the user
	 * @param address				- Indicates the address of the user
	 * 
	 * @pre <code>!hasUser</code>	- user must exist in the system
	 * */
	void updateUser(String userID, String email, String phone, String address);
	
	
	
	/** Removes <code>User</code> in the system identified by <code>userID</code>.
	 * 
	 * @param userID - unique id that identifies user
	 *  
	 * @pre <code>hasUser</code>	- user must exist in the system
	 * @pre <code>!isOwner</code>	- user must not have any homes

	 * */
	void removeUser(String userID);
	
	
	
	/** Consults <code>User</code> data by receiving <code>userID</code>
	 * 
	 * @param userID 				- Indicates the the unique user ID 

	 * @pre <code>hasUser</code>	- user must exist in the system
	 * 
	 * @return user					- <code>User</code> identified by <code>userID</code>
	 * */
	User getUser(String userID);
	
	
	
	/** Adds a <code>Home</code> to rent in the system 
	 * 
	 * @param homeID		- Indicates the unique home ID 
	 * @param userID		- Indicates the unique user ID
	 * @param price			- Indicates the price of the property
	 * @param person		- Indicates the maximum capacity of this home
	 * @param region		- Indicates the region in which this home is located
	 * @param description	- Indicates the description of the home
	 * @param address		- Indicates the address of the home of a user 
	 * 
	 * @pre !hasUser 		- user must exist in system 
	 * @pre !hasHome 		- user must not already own this home
	 * */
	void addHome(String homeID, String userID, int price, int person, String region, String description, String address);
	
	
	
	/** Removes a <code>Home</code> from the system 
	 * 
	 * @param homeID		- Indicates the unique home ID
	 * 
	 * @pre hasHome(String)	- home must exist in the system
	 * @pre !hasTravel		- home must not have any travel
	 * */
	void removeHome(String homeID);
	
	
	
	/** Consults <code>Home</code> data by receiving <code>homeID</code>
	 * 
	 * @param homeID		- Indicates the unique home ID
	 * 
	 * @pre hasHome(String)	- home must exist in the system
	 * 
	 * @return home 		- <code>Home</code> identified by <code>homeID</code>
	 * */
	Home getHome(String homeID);
		
	
	
	/** Adds <code>Travel</code> of <code>User userID</code> to <code>Home homeID</code> 
	 * <code>userID</code> owns <code>homeID Home</code>
	 * 
	 * @param userID		- Indicates the unique user ID
	 * @param homeID		- Indicates the unique home ID
	 * @param score 		- Indicates the score of this Travel. 0 if User is Owner.
	 * 
	 * @pre hasUser			- user must exist in the system
	 * @pre hasHome			- home must exist in the system
	 * @pre score == 0 && isOwner || score > 0 && !isOwner 	
	 */
	void addTravel(String userID, String homeID, int score) throws OwnerScoreException;
	
	
		
	/** Lists all <code>Home</code>s of an <code>Owner</code> receiving <code>userID</code>, sorted by <code>homeID</code>
	 * 
	 * @param userID	- Indicates the unique home ID
	 * 
	 * @pre hasUser 	- user must exist in the system
	 * 
	 * @return <code>Iterator</code> to <code>Home</code>s of<code>userID</code> sorted by <code>homeID</code>
	 * Stage 1 and 2 - returns a single Home (each User only has 1 Home).
	 */
	//Iterator<Home> listHome(String userID);
	Home listHome(String userID);
	
	
	/** Lists all <code>Travel</code>s of a <code>Traveller</code>, sorted from most recent to oldest
	 * 
	 * @param userID	- Indicates the unique user ID
	 * 
	 * @pre hasUser		- user must exist in the system
	 * 
	 * @pre isTraveller	- user must have at least one travel (must be a traveller)
	 * 
	 * @return <code>Iterator</code> to <code>Travel</code>s of <code>userID</code>, sorted from most recent to oldest
	 *  
	 */
	Iterator<Travel> listTraveller(String userID);
	
	
	/** Searches <code>Home</code>s in a <code>region</code> able to receive <code>capacity</code> people
	 *  Sorted by <code>homeID</code>
	 * 
	 * @param capacity				- number of people that must be housed
	 * @param region 				- location in which to search for homes
	 * 
	 * @pre capacity > 0 			- number of people to house must be a positive integer
	 * @pre hasRegion(String, int)	- region must be able to accommodate the given capacity
	 * 
	 * @return <code>Iterator</code> to <code>Home</code>s in <code>region</code> with given or higher <code>capacity</code>
	 * Sorted by <code>homeID</code>
	 */
	//Iterator<Home> pollHome(int capacity, String region);
	Home pollHome(int capacity, String region);
	
	
	/** Lists all <code>Home</code>s available in a <code>region</code>, sorted from best to worst
	 * 
	 * @param region 			- location in which to search for homes
	 * 
	 * @pre hasRegion(String)	- the given region must exist (must have a home)
	 * 
	 * @return <code>Iterator</code> to <code>Home</code>s in <code>region</code> sorted from best to worst
	 * 
	 */
	//Iterator<Home> listBest(String region);
	Home listBest(String region);
	
}
