/**
 * 
 */
package HomeAway;

import java.io.Serializable;
import java.util.Iterator;

/**
 * @author Luis Rosa     - 43612 - lm.rosa@campus.fct.unl.pt
 * @author Diogo Pereira - 44640 - dal.pereira@campus.fct.unl.pt
 */
public interface HomeAway extends Serializable{
	
	public static final int MAX_CAPACITY = 20;     //maximum capacity of a SafeHome.
	public static final int MAX_TRAVEL_SCORE = 20; //maximum score of a Travel.
	
	/**
	 * This interface describes a HomeAway object. It is the top-level interface of this project.
	 */

	/**
	 * Verifies if a SafeUser with the given userID exists in the system
	 * @param String userID - the unique user ID
	 * @return true if user exists, false if not
	 */
	boolean hasUser(String userID);
	
	/**
	 * Verifies if a SafeHome with the given homeID exists in the system
	 * @param String homeID - the unique home ID
	 * @return true if home exists, false if not
	 */
	boolean hasHome(String homeID);
	
	/**
	 * Verifies if a SafeHome with the given homeID exists in the properties of the SafeUser with the given userID
	 * @param String userID 	- the unique user ID of this home's owner
	 * @param String homeID 	- the unique home ID
	 * @return true if home exists and is owned by user, false if not
	 * @exception SafeUser does not exist, SafeHome does not exist.
	 */
	boolean userOwnsHome(String userID, String homeID) throws UserNotFoundException, HomeNotFoundException;
	
	/**
	 * Verifies if the SafeHome with the given homeID has had any Travel to it.
	 * @param String homeID - the unique home ID
	 * @return true if home has had at least one travel, false if not
	 * @exception SafeHome does not exist.
	 */
	boolean hasTravel(String homeID) throws HomeNotFoundException;
	
	/**
	 * Verifies if a SafeRegion with the given regionID exists in the system.
	 * @param String regionID - the unique region name
	 * @return true if region exists, false if not
	 */
	boolean hasRegion(String regionID);
	
	/**
	 * Verifies if the SafeRegion with the given regionID can house the given capacity.
	 * @param String region - the unique region name
	 * @param int capacity  - the capacity to house
	 * @return true if at least one home in region can house the given capacity, false if not
	 * @exception SafeRegion does not exist.
	 */
	boolean regionHasCapacity(String region, int capacity) throws RegionNotFoundException;
	
	/**
	 * Verifies if the SafeUser with the given userID has travelled.
	 * @param userID - the unique user ID
	 * @return true if traveller
	 * @exception SafeUser does not exist, SafeUser is not a traveller
	 */
	boolean isTraveller(String userID) throws UserNotFoundException, UserNotTravellerException;
	
	/**
	 * Verifies if the SafeUser with the given userID is an owner.
	 * @param userID - the unique user ID
	 * @return true if owner
	 * @exception SafeUser does not exist, SafeUser is not owner
	 */
	boolean isOwner(String userID) throws  UserNotFoundException, HomeNotFoundException;

	/**
	 * Returns the SafeRegion with the given identifier.
	 * @param regionID - the Region to search for
	 * @return SafeRegion with identifier regionID
	 * @exception SafeRegion does not exist
	 */
	SafeRegion getRegion(String regionID) throws RegionNotFoundException;
	
	/** 
	 * Returns the SafeUser with the given userID.
	 * @param userID - the unique user ID 
	 * @return SafeUser identified by userID
	 * @exception SafeUser does not exist
	 * */
	SafeUser getUser(String userID) throws UserNotFoundException;
	
	/**
	 * Inserts a SafeUser in the system.
	 * @param userID					- Indicates the unique user ID
	 * @param email						- Indicates the email of the user
	 * @param phone						- Indicates the phone of the user
	 * @param name						- Indicates the name of the user 
	 * @param nationality				- Indicates the nationality of the user
	 * @param address					- Indicates the address of the user
	 * @exception SafeUser already exists
	 */
	void insertUser(String userID, String email, String phone, String name, String nationality, String address) 
			throws DuplicateException;

	/** Updates a SafeUser's information in the system, name and nationality cannot be changed.
	 * @param userID				- Indicates the unique user ID 
	 * @param email					- Indicates the email of the user
	 * @param phone					- Indicates the phone of the user
	 * @param address				- Indicates the address of the user
	 * @exception SafeUser does not exist
	 */
	void updateUser(String userID, String email, String phone, String address) throws UserNotFoundException;
	
	/** Removes SafeUser in the system identified by the given userID.
	 * @param userID - Indicates the unique user ID.
	 * @exception SafeUser does not exist, SafeUser is owner.
	 */
	void removeUser(String userID) throws UserNotFoundException, UserIsOwnerException;
	
	/** Adds a SafeHome to rent in the system.
	 * @param homeID		- Indicates the unique home ID 
	 * @param userID		- Indicates the unique user ID
	 * @param price			- Indicates the price of the property
	 * @param person		- Indicates the maximum capacity of this home
	 * @param region		- Indicates the region in which this home is located
	 * @param description	- Indicates the description of the home
	 * @param address		- Indicates the address of the home of a user
	 * @exception SafeHome already exists, SafeUser does not exist 
	 * */
	void addHome(String homeID, String userID, int price, int person, String region, String description, String address) 
			throws DuplicateException, UserNotFoundException;
	
	/** Removes a SafeHome from the system. 
	 * @param homeID - Indicates the unique home ID
	 * @exception SafeHome does not exist
	 * */
	void removeHome(String homeID)  throws HomeNotFoundException;
	
	/** Returns the SafeHome with the given homeID
	 * @param homeID - Indicates the unique home ID
	 * @return SafeHome identified by homeID
	 * @exception SafeHome does not exist
	 * */
	SafeHome getHome(String homeID) throws HomeNotFoundException;
	
	/** Adds a Travel made by the SafeUser identified by the given userID 
	 * to the SafeHome identified by the given homeID. 
	 * @param userID		- Indicates the unique user ID
	 * @param homeID		- Indicates the unique home ID
	 * @param score 		- Indicates the score of this Travel. 0 if SafeUser is the owner.
	 * @pre score == 0 && isOwner || score > 0 && !isOwner
	 * @exception SafeUser does not exist, SafeHome does not exist 	
	 */
	void addTravel(String userID, String homeID, int score) throws UserNotFoundException, HomeNotFoundException;
		
	/** Lists all SafeHomes of the SafeUser identified by userID, sorted by homeID
	 * @param userID - Indicates the unique user ID
	 * @return Iterator to SafeHomes of SafeUser
	 * @exception SafeUser does not exist, SafeUser is not owner
	 */
	Iterator<SafeHome> listHome(String userID) throws UserNotFoundException, HomeNotFoundException;
	
	/** Lists all Travels of the SafeUser identified by userID.
	 * Travels are sorted from most recent to oldest.
	 * @param userID	- Indicates the unique user ID
	 * @return Iterator to Travels of SafeUser
	 * @exception SafeUser does not exist, SafeUser is not traveller
	 */
	Iterator<Travel> listTravels(String userID) throws UserNotFoundException, UserNotTravellerException;
	
	/** Searches SafeHomes in the SafeRegion identified by the given regionID able to house the given number of people.
	 *  SafesHomes are sorted by increasing capacity and, in case of equal capacity, homeID.
	 * @param capacity	- number of people that must be housed
	 * @param regionID	- location in which to search for homes
	 * @return Iterator to SafeHomes in the given SafeRegion able to house the given number of people.
	 * @exception SafeRegion does not exist, SafeRegion does not have capacity
	 */
	Iterator<SafeHome> pollHome(int capacity, String regionID) throws RegionNotFoundException, NoCapacityException;
	
	/** Lists all SafeHomes available in the SafeRegion identified by the given regionID, sorted from best to worst
	 * @param regionID	- location in which to search for homes
	 * @return Iterator to SafeHomes in SafeRegion sorted from best to worst
	 * @exception SafeRegion does not exist, SafeRegion does not have SafeHomes
	 */
	Iterator<SafeHome> listBest(String region) throws RegionNotFoundException, HomeNotFoundException;
}
