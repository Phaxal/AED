package HomeAway;

/**
 * @author Luis Rosa     - 43612 - lm.rosa@campus.fct.unl.pt
 * @author Diogo Pereira - 44640 - dal.pereira@campus.fct.unl.pt
 */
interface User extends SafeUser {
	
	/**
	 * This interface describes a User object, an alterable instance of a User.
	 */
	
	/**
	 * Updates this User's email, phone and address to the given fields.
	 * @param String email			- Indicates the email of the User.
	 * @param String phone			- Indicates the phone of the User.
	 * @param String address		- Indicates the address of the User.
	 */
	void updateUser(String email, String phone, String address);
	
	/**
	 * Adds a Travel to the given SafeHome.
	 * @param int score - the score given to this Travel. 0 if User is owner of this SafeHome.
	 * @param SafeHome home - the SafeHome to which the Travel was made.
	 */
	void addTravel(int score, SafeHome home);	
	
	/**
	 * Adds a SafeHome to this User.
	 * @param SafeHome home - the home to be added.
	 * @pre !hasHome(homeID)
	 */
	void addHome(SafeHome home);
	
	/**
	 * Removes a SafeHome from this User.
	 * @param SafeHome home - the home to be removed.
	 * @pre hasHome(homeID)
	 * @pre !hasTravel()
	 */
	void removeHome(SafeHome home);
}