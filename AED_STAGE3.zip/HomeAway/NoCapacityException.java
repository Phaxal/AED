package HomeAway;

/**
 * @author Luis Rosa - 43612 - lm.rosa@campus.fct.unl.pt
 * @author Diogo Pereira - 44640 - dal.pereira@campus.fct.unl.pt
 */
public class NoCapacityException extends RuntimeException{

	private static final long serialVersionUID = 0L;
	
	public NoCapacityException() {
		super();
	}

	public NoCapacityException(String message ) {
		super(message);
	}
}