package HomeAway;

/**
 * @author Luis Rosa - 43612 - lm.rosa@campus.fct.unl.pt
 * @author Diogo Pereira - 44640 - dal.pereira@campus.fct.unl.pt
 */
public class HomeNotFoundException extends RuntimeException{

	private static final long serialVersionUID = 0L;
	
	public HomeNotFoundException() {
		super();
	}

	public HomeNotFoundException (String message ) {
		super(message);
	}
}