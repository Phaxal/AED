package HomeAway;

import java.io.Serializable;
import java.util.Iterator;

/**
 * @author Luis Rosa - 43612 - lm.rosa@campus.fct.unl.pt
 * @author Diogo Pereira - 44640 - dal.pereira@campus.fct.unl.pt
 */
public interface SafeUser extends Serializable{
	
	/**
	 * This interface describes a SafeUser object, unalterable representation of a User object, 
	 * for safe passing into the Main Class. A SafeUser can be a traveller, owner of a SafeHome or both.
	 * */
	
	/**
	 * @return true if user has travelled, false if not
	 */	
	boolean hasTravel();
	
	/**
	 * @return true if user owns a home, false if not
	 */	
	boolean hasHome();
	
	/**
	 * Verifies if a given SafeHome is owned by this SafeUser.
	 * @param String homeID - Indicates the unique homeID associated with the SafeHome being requested.
	 * @return true if user owns home, false if not
	 */	
	boolean hasHome(String homeID);
	
	/**
	 * @return userID of this SafeUser
	 */
	String getID();
	
	/**
	 * @return email of this SafeUser
	 */
	String getEmail();
	
	/**
	 * @return phone of this SafeUser
	 */
	String getPhone ();
	
	/**
	 * @return name of this SafeUser
	 */
	String getName();
	
	/**
	 * @return nationality of this SafeUser
	 */
	String getNationality();
	
	/**
	 * @return address of this SafeUser
	 */
	String getAddress();

	/**
	 * Returns this SafeUser's SafeHome with the given key.
	 * @param String homeID - Indicates the unique identifier associated with the SafeHome being requested.
	 * @pre: hasHome(homeID)
	 * @return SafeHome with the given homeID
	 */	
	SafeHome getHome(String homeID);	
	
	/**
	 * Lists all Travels this SafeUser has made, sorted from most recent to oldest.
	 * @return Travel Iterator
	 */
	Iterator <Travel> listTravels();
	
	/**
	 * Lists all SafeHomes this SafeUser owns, SafeHomes are listed in order according to their unique identifier. 
	 * @pre hasHome()
	 * @return SafeHome Iterator
	 */
	Iterator <SafeHome> listHomes();

	/**
	 * @return SafeUser key
	 */
	String getKey();
}