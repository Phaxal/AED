package HomeAway;

/**
 * @author Luis Rosa     - 43612 - lm.rosa@campus.fct.unl.pt
 * @author Diogo Pereira - 44640 - dal.pereira@campus.fct.unl.pt
 */
interface Region extends SafeRegion{
	
	/**
	 * This interface describes a Region object, an alterable instance of a SafeRegion.
	 */

	/**
	 * Adds a SafeHome to this Region.
	 * @param: SafeHome home - home to insert.
	 * @pre: !hasHome(homeID)
	 */
	void addHome(SafeHome home);
	
	/**
	 * Removes a SafeHome from this Region.
	 * @param: <code>Home</code> home - home to remove.
	 * @pre: !hasTravel
	 */
	void removeHome(SafeHome home);
}