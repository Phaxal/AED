package HomeAway;

import java.util.Comparator;

/**
 * @author Luis Rosa - 43612 - lm.rosa@campus.fct.unl.pt
 * @author Diogo Pereira - 44640 - dal.pereira@campus.fct.unl.pt
 */
public class ComparatorByCapacity implements Comparator<SafeHome>{
	
		@Override
		public int compare(SafeHome o1, SafeHome o2) {
			
			if (o1.getCapacity() < o2.getCapacity())
				return -1;
			if (o1.getCapacity() > o2.getCapacity())
				return 1;	
			return o1.getKey().compareTo(o2.getKey());			
	}
}
