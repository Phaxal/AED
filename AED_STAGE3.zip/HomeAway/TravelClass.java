/**
 * 
 */
package HomeAway;

/**
 * @author Luis Rosa     - 43612 - lm.rosa@campus.fct.unl.pt
 * @author Diogo Pereira - 44640 - dal.pereira@campus.fct.unl.pt
 */
public class TravelClass implements Travel {
	
	private static final long serialVersionUID = 0L;

	private int score;
	private SafeHome home;
	
	public TravelClass(int score, SafeHome home){
		this.score = score;
		this.home = home;
	}
	
	@Override
	public int getScore() {
		return score;
	}

	@Override
	public SafeHome getHome() {
		return home;
	}
}