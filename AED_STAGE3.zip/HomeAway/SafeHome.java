package HomeAway;

import java.io.Serializable;

/**
 * @author Luis Rosa - 43612 - lm.rosa@campus.fct.unl.pt
 * @author Diogo Pereira - 44640 - dal.pereira@campus.fct.unl.pt
 */
public interface SafeHome extends Serializable{
	/**
	 * An interface describing a SafeHome object, unalterable representation of a Home object, 
	 * for safe passing into the Main Class.
	 */
	
	/**
	 * @return true if this SafeHome has had at least one Travel, false if not
	 */
	boolean hasTravel();
	
	/**
	 * @return the homeID of this SafeHome
	 */
	String getID();
	
	/**
	 * @return the description of this SafeHome
	 */
	String getDescription();
	
	/**
	 * @return the address of this SafeHome
	 */
	String getAddress();
	
	/**
	 * @return the SafeUser owner of this SafeHome
	 */
	SafeUser getUser();
	
	/**
	 * @return the price of a Travel to this SafeHome
	 */
	int getPrice();
	
	/**
	 * @return the number of people this SafeHome can house.
	 */
	int getCapacity();
	
	/**
	 * @return the accumulated score of this SafeHome.
	 */
	int getTotalScore();	
	
	/**
	 * @return the unique region identifier of the SafeRegion where this SafeHome is located
	 */
	String getRegion();
	
	/**
	 * @return the key associated with this SafeHome
	 */
	String getKey();
}