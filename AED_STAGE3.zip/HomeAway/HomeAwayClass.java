package HomeAway;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

/**
 * @author Luis Rosa - 43612 - lm.rosa@campus.fct.unl.pt
 * @author Diogo Pereira - 44640 - dal.pereira@campus.fct.unl.pt
 */

public class HomeAwayClass implements HomeAway {

	private static final long serialVersionUID = 0L;

	private Map<String, User> users;
	private Map<String, Region> regions;
	private Map<String, Home> homes;
	
	public HomeAwayClass() {
		regions = new HashMap<String, Region>();
		users = new HashMap<String, User>();
		homes = new HashMap<String, Home>();
	}

	@Override
	public boolean hasUser(String userID) {
		return users.containsKey(userID.toLowerCase());
	}

	@Override
	public boolean hasHome(String homeID) {
		return homes.containsKey(homeID.toLowerCase()); 			
	}

	@Override
	public boolean userOwnsHome(String userID, String homeID) throws UserNotFoundException, HomeNotFoundException{
		if (!hasUser(userID))
			throw new UserNotFoundException();
		if (!hasHome(homeID))
			throw new HomeNotFoundException();
		return getUser(userID).hasHome(homeID);
	}

	@Override
	public boolean hasTravel(String homeID) throws HomeNotFoundException{
		if (!hasHome(homeID))
			throw new HomeNotFoundException();
		return getHome(homeID).hasTravel();
	}

	@Override
	public boolean hasRegion(String region) {
		return regions.containsKey(region.toLowerCase());
	}

	@Override
	public boolean regionHasCapacity(String region, int capacity) throws RegionNotFoundException {
		if (hasRegion(region))
			return regions.get(region.toLowerCase()).getRegionCapacity() >= capacity;
		throw new RegionNotFoundException();
	}

	@Override
	public boolean isTraveller(String userID) throws UserNotFoundException, UserNotTravellerException{
		if (!hasUser(userID))
			throw new UserNotFoundException();
		if (getUser(userID).hasTravel())
			return true;
		throw new UserNotTravellerException();
	}

	@Override
	public boolean isOwner(String userID) throws UserNotFoundException, HomeNotFoundException {
		if (!hasUser(userID))
			throw new UserNotFoundException();
		if (getUser(userID).hasHome())
			return true;
		throw new HomeNotFoundException();
	}

	@Override
	public SafeUser getUser(String userID) throws UserNotFoundException {
		if (!hasUser(userID)) throw new UserNotFoundException();
		return (SafeUser)users.get(userID.toLowerCase());
	}

	@Override
	public void insertUser(String userID, String email, String phone, String name, String nationality, String address)
			throws DuplicateException {
		if (hasUser(userID))
			throw new DuplicateException();
		else {
			User user = new UserClass(userID, email, phone, address, name, nationality);
			users.put(userID.toLowerCase(), user);
		}
	}

	@Override
	public void updateUser(String userID, String email, String phone, String address) throws UserNotFoundException {
		if (hasUser(userID))
			((User) users.get(userID)).updateUser(email, phone, address);
		else throw new UserNotFoundException();
	}

	@Override
	public void removeUser(String userID) throws UserNotFoundException, UserIsOwnerException {
		if (hasUser(userID)){
			if (!getUser(userID).hasHome())
				users.remove(userID.toLowerCase());
			else throw new UserIsOwnerException();
		}
		else throw new UserNotFoundException();
	}

	@Override
	public void addHome(String homeID, String userID, int price, int capacity, String region, String description, String address)
			throws DuplicateException, UserNotFoundException {

		if (!hasUser(userID))
			throw new UserNotFoundException();
		if (hasHome(homeID))
			throw new DuplicateException();
		if (!this.hasRegion(region))
			regions.put(region.toLowerCase(), new RegionClass(region));

		Home home = new HomeClass(homeID, getUser(userID), price, capacity, region, description, address);
		homes.put(homeID.toLowerCase(), home);
		regions.get(region.toLowerCase()).addHome(home);
		((User) getUser(userID.toLowerCase())).addHome(home);
	}

	@Override
	public void removeHome(String homeID) throws HomeNotFoundException, HomeHasTravelException {
		if (hasHome(homeID)) {
			SafeHome home = getHome(homeID);
			if (home.hasTravel())
				throw new HomeHasTravelException();
			((Region)regions.get(home.getRegion().toLowerCase())).removeHome(home);
			((User)(home.getUser())).removeHome(home);
			homes.remove(homeID.toLowerCase());
		} else throw new HomeNotFoundException();
	}

	@Override
	public SafeHome getHome(String homeID) throws HomeNotFoundException {
		if (!hasHome(homeID)) throw new HomeNotFoundException();
		return (SafeHome) homes.get(homeID.toLowerCase());
	}

	@Override
	public void addTravel(String userID, String homeID, int score) throws UserNotFoundException, HomeNotFoundException {
		((User)getUser(userID)).addTravel(score, getHome(homeID));
	}

	@Override
	public Iterator<SafeHome> listHome(String userID) throws UserNotFoundException, HomeNotFoundException {
		if (hasUser(userID)) {
			if (getUser(userID.toLowerCase()).hasHome()) 
				return getUser(userID.toLowerCase()).listHomes();
			throw new HomeNotFoundException();
		} throw new UserNotFoundException();
	}

	@Override
	public Iterator<Travel> listTravels(String userID) throws UserNotFoundException, UserNotTravellerException {
		if (!this.hasUser(userID))
			throw new UserNotFoundException();
		if (!isTraveller(userID))
			throw new UserNotTravellerException();
		return getUser(userID).listTravels();
	}

	@Override
	public Iterator<SafeHome> pollHome(int capacity, String region) throws RegionNotFoundException, NoCapacityException {	
		if (hasRegion(region)) {
			SafeRegion reg = getRegion(region);
			if (reg.hasHome()){
				if (reg.getRegionCapacity() >= capacity)
					return reg.pollHome(capacity);
			} throw new NoCapacityException();
		} throw new RegionNotFoundException();		
	}

	@Override
	public Iterator<SafeHome> listBest(String region) throws RegionNotFoundException, HomeNotFoundException {
		if (!hasRegion(region))
			throw new RegionNotFoundException();
		SafeRegion reg = getRegion(region);
		if (reg.hasHome())
			return getRegion(region).listBest();
		throw new HomeNotFoundException();
	}
	
	@Override
	public SafeRegion getRegion(String regionID) throws RegionNotFoundException {
		if (!hasRegion(regionID))
			throw new RegionNotFoundException();
		return regions.get(regionID.toLowerCase());
	}
}
