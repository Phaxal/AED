package HomeAway;

import java.io.Serializable;
import java.util.Iterator;

/**
 * @author Luis Rosa - 43612 - lm.rosa@campus.fct.unl.pt
 * @author Diogo Pereira - 44640 - dal.pereira@campus.fct.unl.pt
 */
public interface SafeRegion extends Serializable{

	/**
	 * An interface describing a SafeRegion object, unalterable representation of a Region object, 
	 * for safe passing into the Main Class.
	 */
	
	/**
	 * Lists all SafeHomes available for renting in this SafeRegion, 
	 * sorted by accumulated score, from highest rated to lowest rated.
	 * If two or more SafeHomes have the same score, they are sorted by their unique identifier.
	 * @return Iterator to highest rated SafeHomes
	 */ 
	 Iterator<SafeHome> listBest();
	 
	 /** 
	 * Lists all SafeHomes available for renting in this SafeRegion that can accommodate the given number of people.
	 * Two SafeHomes with the same capacity are sorted by their unique identifier. 
	 * @param: int capacity - number of people to accommodate.
	 * @return Iterator to SafeHomes with given capacity, sorted by increasing capacity. 
	 */ 
	 Iterator <SafeHome> pollHome(int capacity);
	 
	/**
	 * @return true if SafeRegion has at least one SafeHome, false if not.
	 */
	boolean hasHome();

	/**
	 * @return the maximum capacity of the SafeHome with the most capacity in this SafeRegion
	 */
	int getRegionCapacity();
	
	/**
	 * @return the unique SafeRegion identifier (name)
	 */
	String getRegionName();
	
	/**
	 * @return key associated with this SafeRegion
	 */
	String getKey();
}