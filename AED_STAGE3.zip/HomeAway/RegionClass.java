package HomeAway;

import java.util.List;
import java.util.Map;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.Iterator;

/**
 * @author Luis Rosa - 43612 - lm.rosa@campus.fct.unl.pt
 * @author Diogo Pereira - 44640 - dal.pereira@campus.fct.unl.pt
 */
class RegionClass implements SafeRegion, Region {
	
	private static final long serialVersionUID = 1L;
	
	private String key, name;
	private int maxCapacity;
	private Map<String, SafeHome> homes;

	public RegionClass(String name){
		this.key = name.toLowerCase();
		this.name = name;
		homes = new HashMap<String, SafeHome>();
		maxCapacity = 0;
	}
	
	@Override
	public String getRegionName(){
		return name;
	}
	
	@Override
	public String getKey(){
		return key;
	}
	
	@Override
	public int getRegionCapacity(){
		return maxCapacity;
	}
	
	@Override
	public boolean hasHome() {
		return !homes.isEmpty();
	}

	@Override	
	public Iterator<SafeHome> listBest() {
		Comparator<SafeHome> compareByScore = new ComparatorByScore();
		List<SafeHome> homesByScore = new ArrayList<SafeHome>(homes.values());
		Collections.sort(homesByScore, compareByScore);
		return homesByScore.iterator();
	}

	@Override
	public Iterator<SafeHome> pollHome(int capacity) throws NoCapacityException{
		//order by capacity, if equal capacity then by ID
		Comparator<SafeHome> compareByCapacity = new ComparatorByCapacity();
		List<SafeHome> homesByCapacity = new ArrayList<SafeHome>(homes.values());
		Collections.sort(homesByCapacity, compareByCapacity);
		Iterator<SafeHome> it = homesByCapacity.iterator();
		int counter = 0;
		
		while (it.hasNext()){
			SafeHome home = it.next();
			if (home.getCapacity() < capacity)
				counter++;
			else break;
		}
		it = homesByCapacity.subList(counter, homesByCapacity.size()).iterator();
		if (!it.hasNext()) throw new NoCapacityException();
		return it;
	}

	@Override
	public void addHome(SafeHome home) {
		if (home.getCapacity() > maxCapacity)
			maxCapacity = home.getCapacity();
		homes.put(home.getKey(), home);
	}

	@Override
	public void removeHome(SafeHome home) {
		homes.remove(home.getKey());
		if (home.getCapacity() == getRegionCapacity()){
			int capacity = 0;
			Iterator<SafeHome> it = homes.values().iterator();
			while(it.hasNext() && capacity != home.getCapacity())
				capacity = it.next().getCapacity();
			maxCapacity = capacity;
		}
	}
}