package HomeAway;

import java.util.SortedMap;
import java.util.TreeMap;
import java.util.Deque;
import java.util.LinkedList;
import java.util.Iterator;

/**
 * @author Luis Rosa     - 43612 - lm.rosa@campus.fct.unl.pt
 * @author Diogo Pereira - 44640 - dal.pereira@campus.fct.unl.pt
 */
class UserClass implements SafeUser, User {
	
	private static final long serialVersionUID = 1L;
	
	private String userID, userKey, name, nationality, address, email, phone;
	private SortedMap<String, SafeHome> userHomes;
	private Deque<Travel> travels;
	
	public UserClass(String userID, String email, String phone, String address, String name, String nationality){
		userHomes = new TreeMap<String, SafeHome>();
		travels = new LinkedList<Travel>();
		this.userID = userID;
		this.userKey = userID.toLowerCase();
		this.name = name;
		this.nationality = nationality;
		this.email = email;
		this.phone = phone;
		this.address = address;
	}

	@Override
	public boolean hasTravel() {
		return !travels.isEmpty();
	}

	@Override
	public boolean hasHome() {
		return !userHomes.isEmpty();
	}

	@Override
	public boolean hasHome(String homeID) {
		return userHomes.containsKey(homeID.toLowerCase());
	}

	@Override
	public String getID() {
		return userID;
	}
	
	@Override
	public String getKey() {
		return userKey;
	}

	@Override
	public String getEmail() {
		return email;
	}

	@Override
	public String getPhone() {
		return phone;
	}

	@Override
	public String getName() {
		return name;
	}

	@Override
	public String getNationality() {
		return nationality;
	}

	@Override
	public String getAddress() {
		return address;
	}

	@Override
	public SafeHome getHome(String homeID) {
		return userHomes.get(homeID.toLowerCase());
	}

	@Override
	public Iterator<Travel> listTravels() {
		return travels.descendingIterator();
	}

	@Override
	public Iterator<SafeHome> listHomes() {
		return userHomes.values().iterator();
	}
	
	private void setEmail(String email) {
		this.email = email;
	}

	private void setPhone(String phone) {
		this.phone = phone;
	}

	private void setAddress(String address) {
		this.address = address;
	}

	@Override
	public void updateUser(String email, String phone, String address) {
		setEmail(email);
		setPhone(phone);
		setAddress(address);
	}
	
	@Override
	public void addHome(SafeHome home) {
		this.userHomes.put(home.getKey(), home);
	}
	
	@Override
	public void removeHome(SafeHome home) {
		this.userHomes.remove(home.getKey());
	}
	
	@Override
	public void addTravel(int score, SafeHome home) {
		Travel travel = new TravelClass(score, home);
		travels.addLast(travel);
		((Home) home).addTravel(score, travel);
	}
}