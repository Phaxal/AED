/**
 * 
 */
package HomeAway;

import java.io.Serializable;
/**
 * @author Luis Rosa     - 43612 - lm.rosa@campus.fct.unl.pt
 * @author Diogo Pereira - 44640 - dal.pereira@campus.fct.unl.pt
 */
interface Home extends SafeHome, Serializable{

	/**
	 * This interface describes a Home object, an alterable instance of a SafeHome.
	 */

	/**
	 * Adds a Travel to this Home.
	 * @param Travel travel - the travel to be added. 
	 */
	void addTravel(int score, Travel travel);
}
