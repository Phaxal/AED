package HomeAway;

import java.util.LinkedList;
import java.util.List;

/**
 * @author Luis Rosa - 43612 - lm.rosa@campus.fct.unl.pt
 * @author Diogo Pereira - 44640 - dal.pereira@campus.fct.unl.pt
 */

class HomeClass implements SafeHome, Home {

	private static final long serialVersionUID = 1L;

	private String homeID, homeKey, region, description, address;
	private int price, capacity, totalScore;
	private SafeUser owner;
	private List<Travel> travels;

	public HomeClass(String homeID, SafeUser owner, int price, int capacity, String region, String description,
			String address) {
		totalScore = 0;
		this.homeID = homeID;
		this.homeKey = homeID.toLowerCase();
		this.owner = owner;
		this.price = price;
		this.capacity = capacity;
		this.description = description;
		this.address = address;
		this.region = region;
		travels = new LinkedList<Travel>();	
	}

	@Override
	public boolean hasTravel() {
		return !travels.isEmpty();
	}

	@Override
	public String getDescription() {
		return description;
	}

	@Override
	public String getAddress() {
		return address;
	}

	@Override
	public String getID() {
		return homeID;
	}

	@Override
	public SafeUser getUser() {
		return owner;
	}

	@Override
	public String getKey() {
		return homeKey;
	}

	@Override
	public int getPrice() {
		return price;
	}

	@Override
	public int getCapacity() {
		return capacity;
	}

	@Override
	public int getTotalScore() {
		return totalScore;
	}

	@Override
	public String getRegion() {
		return region;
	}

	@Override
	public void addTravel(int score, Travel travel) {
		this.totalScore += score;
		travels.add(travel);
	}
}
