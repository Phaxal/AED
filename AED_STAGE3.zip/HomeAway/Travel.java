package HomeAway;

import java.io.Serializable;

/**
 * @author Luis Rosa     - 43612 - lm.rosa@campus.fct.unl.pt
 * @author Diogo Pereira - 44640 - dal.pereira@campus.fct.unl.pt
 */
public interface Travel extends Serializable{
	
	/**
	 * This interface describes a Travel object.
	 */

	/**
	 * @return SafeHome of this Travel
	 */
	SafeHome getHome();
	
	/**
	 * @return Score of this Travel
	 */
	int getScore();
}