package dataStructures;

/**
 * @author Luis Rosa     - 43612 - lm.rosa@campus.fct.unl.pt
 * @author Diogo Pereira - 44640 - dal.pereira@campus.fct.unl.pt
 */
public class BSTKeyOrderIterator<K extends Comparable<K>, V> implements Iterator<Entry <K,V>> {

	private static final long serialVersionUID = 1L;
	private BSTNode<K,V> root; 
	private Stack<BSTNode<K,V>> stack;
	
	public BSTKeyOrderIterator(BSTNode<K,V> root){
		stack = new StackInList<BSTNode<K,V>>();
		this.root = root;
		rewind();
	}
	
	@Override
	public void rewind() {
		pushLeftNode(root);
	}

	@Override
	public boolean hasNext() {
		return !stack.isEmpty();
	}

	@Override
	public Entry<K, V> next() throws NoSuchElementException {
		if(!hasNext())
			throw new NoSuchElementException();
		
		if(stack.top().getRight() == null)
			return stack.pop().getEntry();
		
		BSTNode<K,V> top = stack.top();
		stack.pop();
		pushLeftNode(top.getRight());
		return top.getEntry();
	}
	
	private void pushLeftNode(BSTNode<K,V> node){
		if(node != null){
			stack.push(node);
			pushLeftNode(node.getLeft());
		}
	}
}