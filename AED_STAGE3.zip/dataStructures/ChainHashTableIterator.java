package dataStructures;

public class ChainHashTableIterator<K, V> implements Iterator<Entry<K,V>>{

	private static final long serialVersionUID = 1L;
	
	int currentIndex;
	
	protected Iterator<Entry<K,V>>[] iterator;

	public ChainHashTableIterator(Iterator<Entry<K,V>>[] it){
		this.iterator = it;
	}
	
	public boolean hasNext() {
		while(currentIndex<iterator.length && !iterator[currentIndex].hasNext()){
			currentIndex++;
		}
		return (currentIndex < iterator.length);
	}

	public Entry<K, V> next() throws NoSuchElementException {
		if(!hasNext()){
			throw new NoSuchElementException();
		}
		return iterator[currentIndex].next();
	}

	public void rewind() {
		for(int i=0;i<iterator.length;i++){
			iterator[i].rewind();
		}
	}

}
