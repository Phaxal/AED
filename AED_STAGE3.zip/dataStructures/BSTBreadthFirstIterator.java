package dataStructures;

public class BSTBreadthFirstIterator <K extends Comparable<K>, V> implements Iterator<Entry<K, V>> {

	private static final long serialVersionUID = 1L;

	public BSTBreadthFirstIterator(){
		
	}
	public BSTBreadthFirstIterator(BSTNode<K, V> root) {
		// TODO Auto-generated constructor stub
	}
	@Override
	public void rewind() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public boolean hasNext() {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public Entry<K, V> next() throws NoSuchElementException {
		// TODO Auto-generated method stub
		return null;
	}
	
	

}
