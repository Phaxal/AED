package dataStructures;

import java.io.Serializable;

public class InvertibleQueueInList<E> extends QueueInList<E> implements InvertibleQueue<E>, Serializable{

	private static final long serialVersionUID = 1L;

	private boolean inverted;
	
	public InvertibleQueueInList() {
		super();
		inverted = false;
	}

	@Override
	public void invert() {
		inverted = !inverted;
	}
	
	public void enqueue (E elem){
		if (inverted != true)
			list.addLast(elem);
		else
			list.addFirst(elem);
	}
	
	public E dequeue () throws EmptyQueueException{
		E elem;
		if (inverted != true){
			elem = list.removeFirst();
		}
		else
			elem = list.removeLast();
		return elem;
	}
}
