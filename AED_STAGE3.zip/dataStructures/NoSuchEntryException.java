package dataStructures;

/**
 * @author Luis Rosa     - 43612 - lm.rosa@campus.fct.unl.pt
 * @author Diogo Pereira - 44640 - dal.pereira@campus.fct.unl.pt
 */
public class NoSuchEntryException extends Exception {

	public class NoSuchElementException extends Exception {

		private static final long serialVersionUID = 1L;

	}

}
